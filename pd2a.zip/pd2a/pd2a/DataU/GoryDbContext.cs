﻿using Microsoft.EntityFrameworkCore;
using pd2a.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pd2a.Data
{
    public class GoryDbContext : DbContext
    {
        public DbSet<Gory> Gory { get; set; }
        public GoryDbContext(DbContextOptions<GoryDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Gory>()
        .HasKey(g => g.Id);
            modelBuilder.Entity<Gory>()
              .Property(g => g.Id)
              .ValueGeneratedOnAdd();

            modelBuilder.Entity<Gory>().HasData(
              new Gory() { Id = 1, Nazwa = "Bieszczady", Opis = "Opis.", Zdjecie = "bieszczady.jpg" },
              new Gory() { Id = 2, Nazwa = "Tatry", Opis = "Opis.", Zdjecie = "tatry.jpg" }
            );
        }
    }
}
