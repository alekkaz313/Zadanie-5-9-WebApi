﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace pd2a.DataU.Migrations
{
    public partial class Initialgg : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
