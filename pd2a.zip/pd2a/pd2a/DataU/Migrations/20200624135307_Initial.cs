﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace pd2a.DataU.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Gory",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Nazwa = table.Column<string>(nullable: true),
                    Opis = table.Column<string>(nullable: true),
                    Zdjecie = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gory", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Uzytkownicy",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Typ = table.Column<string>(nullable: true),
                    Login = table.Column<string>(nullable: true),
                    Haslo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Uzytkownicy", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Gory",
                columns: new[] { "Id", "Nazwa", "Opis", "Zdjecie" },
                values: new object[] { 1, null, null, null });

            migrationBuilder.InsertData(
                table: "Gory",
                columns: new[] { "Id", "Nazwa", "Opis", "Zdjecie" },
                values: new object[] { 2, null, null, null });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Gory");

            migrationBuilder.DropTable(
                name: "Uzytkownicy");
        }
    }
}
