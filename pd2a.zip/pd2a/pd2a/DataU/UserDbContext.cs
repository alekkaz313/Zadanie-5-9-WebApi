﻿using Microsoft.EntityFrameworkCore;
using pd2a.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pd2a.Data
{
    public class UserDbContext : DbContext
    {
        public DbSet<Uzytkownicy> Uzytkownicy { get; set; }
        public UserDbContext(DbContextOptions<UserDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Uzytkownicy>()
        .HasKey(g => g.Id);
            modelBuilder.Entity<Uzytkownicy>()
              .Property(g => g.Id)
              .ValueGeneratedOnAdd();
            modelBuilder.Entity<Uzytkownicy>().HasData(
              new Uzytkownicy() { Id = 1, Typ = "Admin", Login = "admin", Haslo = "admin" },
              new Uzytkownicy() { Id = 2, Typ = "User", Login = "user", Haslo = "user" }
            );
        }
    }
}
