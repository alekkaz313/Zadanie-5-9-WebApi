﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using pd2a.Data;
using pd2a.Models;

namespace pd2a.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class GoryController : ControllerBase
    {
        private readonly GoryDbContext _context;

        public GoryController(GoryDbContext context)
        {
            _context = context;
        }

        // GET: api/Gory
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Gory>>> GetGory()
        {
            return await _context.Gory.ToListAsync();
        }

        // GET: api/Gory/5
        [Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        public async Task<ActionResult<Gory>> GetGory(int id)
        {
            var gory = await _context.Gory.FindAsync(id);

            if (gory == null)
            {
                return NotFound();
            }

            return gory;
        }

        // PUT: api/Gory/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [Authorize(Roles = "Admin")]
        [HttpPut("zmien/{id}")]
        public async Task<IActionResult> PutGory(int id, Gory gory)
        {
            if (id != gory.Id)
            {
                return BadRequest();
            }

            _context.Entry(gory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Gory
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [Authorize(Roles = "Admin")]
        [HttpPost("dodaj")]
        public async Task<ActionResult<Gory>> PostGory(Gory gory)
        {
            _context.Gory.Add(gory);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetGory", new { id = gory.Id }, gory);
        }

        // DELETE: api/Gory/5
        [Authorize(Roles = "Admin")]
        [HttpDelete("usun/{id}")]
        public async Task<ActionResult<Gory>> DeleteGory(int id)
        {
            var gory = await _context.Gory.FindAsync(id);
            if (gory == null)
            {
                return NotFound();
            }

            _context.Gory.Remove(gory);
            await _context.SaveChangesAsync();

            return gory;
        }

        private bool GoryExists(int id)
        {
            return _context.Gory.Any(e => e.Id == id);
        }
      
    }
}

