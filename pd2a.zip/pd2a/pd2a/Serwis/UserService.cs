﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using pd2a.Data;
using pd2a.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace pd2a.Serwis
{
    public interface IUserService
    {
        AuthenticateDto Authenticate(string login, string haslo);
    }

    public class UserService : IUserService
    {
        
        private List<Uzytkownicy> _users = new List<Uzytkownicy>
        {
            new Uzytkownicy { Id = 1, Typ = "User", Login = "user", Haslo = "user" },
            new Uzytkownicy { Id = 2, Typ = "Admin", Login = "admin", Haslo = "admin" }
        };

        private readonly AppSettings _appSettings;

        public UserService(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }

        public AuthenticateDto Authenticate(string login, string haslo)
        {

            var user = _users.SingleOrDefault(x => x.Login == login && x.Haslo == haslo);

            if (user == null)
                return null;
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, user.Id.ToString()),
                    new Claim(ClaimTypes.Role, user.Typ)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);

            AuthenticateDto userDto = new AuthenticateDto();
            userDto.Token = tokenHandler.WriteToken(token);
            userDto.Role = user.Typ;

            return userDto;
            {

            }



        }

    }
}
