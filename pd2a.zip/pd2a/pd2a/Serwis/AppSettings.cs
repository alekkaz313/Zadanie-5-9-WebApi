﻿namespace pd2a.Serwis
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}