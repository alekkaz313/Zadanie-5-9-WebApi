﻿using pd2a.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pd2a.Serwis
{
    public class AuthenticateResponse
    {
        public int Id { get; set; }
        public string Typ { get; set; }
        public string Login { get; set; }
        public string Haslo { get; set; }
        public string Token { get; set; }


        public AuthenticateResponse(Uzytkownicy user, string token)
        {
            Id = user.Id;
            Typ = user.Typ;
            Login = user.Login;
            Haslo = user.Haslo;
            Token = token;
        }
    }
}
