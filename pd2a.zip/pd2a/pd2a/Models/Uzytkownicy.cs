﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pd2a.Models
{
    public class Uzytkownicy
    {
        public int Id { get; set; }
        public string Typ { get; set; }
        public string Login { get; set; }
        public string Haslo { get; set; }
    }
}
